Boxicons License
-------------------------Boxicons is an open source project , you can use them in your commercial projects too.
The icons (.svg) files are free to download are licensed under CC 4.0 .
The fonts files are licensed under SIL OFL 1.1
Attribution is not required but is appreciated
Other files which are not fonts or icons are licensed under the MIT License